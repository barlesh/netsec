

def enc(data):
    return data

def dec(data):
    return data